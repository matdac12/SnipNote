## Task 1: Resolve truthful analysis states

**Files:** Create the first three production files and `SnipNoteTests/AnalysisPresentationTests.swift`.

**Interfaces:**
- `AnalysisPresentationInput.init(meetingID: UUID, jobID: String? = nil, backend: TranscriptionBackend? = .cloud, processingState: ProcessingState = .transcribing, processingPhase: MeetingProcessingPhase = .preparing, upload: BackgroundUploadManifest? = nil, serverStatus: JobStatus? = nil, serverStage: String? = nil, canRetry: Bool = false, canRetryAnalysis: Bool = false)`.
- `@MainActor AnalysisPresentationInput.init(meeting: Meeting, upload: BackgroundUploadManifest?, serverStatus: JobStatus?, serverStage: String?)` copies fields only; when the supplied serverStage is nil/empty, use meeting.currentStageDescription as persisted presentation evidence only for an accepted job. Never classify arbitrary local stage text as server state.
- `AnalysisPresentation.Phase`: `preparing`, `uploading`, `confirmingUpload`, `queued`, `transcribing`, `analyzing`, `processing`, `pausedUpload`, `failed`, `foreground`, `results`.
- `AnalysisPresentation.Guidance`: `keepOpen`, `safeUpload`, `safeServer`, `needsAttention`, `none`.
- `AnalysisPresentation` stores `meetingID: UUID`, `jobID: String?`, `phase: Phase`, `guidance: Guidance`, `uploadFraction: Double?`, `sentBytes: Int64?`, `totalBytes: Int64?`, `canRetryUpload: Bool`; `canLeave: Bool` is true only for safeUpload/safeServer. Equatable conformance for the value and nested enums.
- `AnalysisPresentationResolver.resolve(_ input: AnalysisPresentationInput, previous: AnalysisPresentation? = nil) -> AnalysisPresentation`.
- `AnalysisPresentationResolver.serverPhase(status: JobStatus, stage: String?) -> AnalysisPresentation.Phase` is shared with Task 3.

- [ ] **Step 1: Write resolver tests with real manifest values.** In the test suite define `upload(phase: BackgroundUploadPhase = .uploading, sent: Int64 = 0, total: Int64 = 100, registered: Bool = true) -> BackgroundUploadManifest`: one `PreparedUploadFile`, state `.scheduled` when registered, `.pending` otherwise, chosen sent bytes. Set manifest meetingID to the tested ID. No transport/network mocks are needed here.

```swift
@Test func safeAtZeroBytesOnlyAfterRegistration() {
  let id = UUID()
  var ready = upload(sent: 0); ready.meetingID = id
  let safe = AnalysisPresentationResolver.resolve(.init(meetingID: id, upload: ready))
  #expect(safe.phase == .uploading && safe.canLeave)
  #expect(safe.uploadFraction == 0)
  ready.files[0].state = .pending
  let waiting = AnalysisPresentationResolver.resolve(.init(meetingID: id, upload: ready))
  #expect(waiting.phase == .preparing && !waiting.canLeave)
}
```

Add named tests with these assertions: `noSnapshotStartsPreparing` → preparing/keepOpen/no fraction; `allBytesSentMeansConfirmation` → confirmingUpload/safeUpload/fraction 1, not results; `emptyOrZeroTotalFilesNeverAuthorizeLeaving` → keepOpen/no fraction even if the existing allSatisfy property returns true; `retryOverridesStaleSafeState` → pausedUpload/needsAttention/canRetryUpload, no safe message; `localAndForegroundCloudNeverInheritSafety` → foreground/keepOpen without manifest and no accepted server job; `foreignManifestIsIgnored` → mismatched meeting IDs do not confer permission; `cancelledManifestDoesNotConferSafety` → needsAttention; `terminalMeetingWins` → completed model/results regardless of stale manifest, failed model/failed without safe guidance.

Add `queuedManifestUsesRunningJob` → queued snapshot plus processing/transcription stage yields transcribing/safeServer; `serverFailureWinsQueuedManifest` → failed/no safety; `remoteCompleteWaitsForAppliedResults` → completed remote status with transcribing model yields processing/safeServer, not results; `statusGapPreservesSameJobOnly` → nil status retains previous server phase only for the same meeting/job and no contradictory retry/terminal evidence; `freshReturnUsesPersistedPhase` → jobID plus persisted generatingSummary yields analyzing/safeServer without prior view state; `stalledBytesDoNotAdvance` → identical byte samples produce identical fraction; `malformedProgressIsBounded` → negative sent clamps to 0, excess sent clamps to total, nonpositive total gives no fraction.

- [ ] **Step 2: Run UNIT filtered to `AnalysisPresentationTests`.** Expected RED: missing presentation types, not a simulator/cache error.
- [ ] **Step 3: Implement the interfaces above.** Resolver precedence: terminal model; explicit local route; matching active manifest recovery/cancellation; manifest preparing/unregistered; registered upload/confirmation; accepted server job (queued snapshot or existing jobID); foreground fallback. Server failure overrides queued presentation. A jobID is created after legacy upload acceptance, so pending with a jobID means queued, not upload. Use previous only to bridge missing server metadata for the same identity; fresh input wins, and previous safety never overrides recovery or an absent transfer guarantee.

Normalize known service strings from `../snipnote-transcription-service/jobs.py` and `transcribe.py`: prefixes `Transcribing`, `Merging transcripts`, `Combining transcripts`, or `Transcription complete` → transcribing; `Generating summary`, `Summary generated`, `Generating overview`, or `AI content generated` → analyzing; other processing-stage strings → processing. Ignore case and trim whitespace. Unknown/nil stage must show generic processing, never raw English server text or invented percentage/ETA. Add parameterized tests for these exact strings and an unknown string. Persisted generatingOverview/generatingSummary can restore analyzing when live status is absent.

- [ ] **Step 4: Run UNIT filtered to `AnalysisPresentationTests`.** Expected GREEN, no skipped resolver tests.
- [ ] **Step 5: Commit the four task files.** `git commit -m "Add analysis presentation resolver"`. End-of-task contract: UNIT filtered to `AnalysisPresentationTests`.

