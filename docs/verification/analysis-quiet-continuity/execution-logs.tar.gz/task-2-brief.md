## Task 2: Build the quiet, localized, accessible surface

**Files:** Create `AnalysisStatusView.swift`, `AnalysisAnnouncementTracker.swift`, announcement/localization tests; modify Theme, LocalizationManager, and catalog.

**Interfaces:**
- Consumes Task 1's `AnalysisPresentation`.
- `AnalysisStatusView.init(presentation: AnalysisPresentation, retryUpload: (() -> Void)? = nil)`; ThemeManager and LocalizationManager are environment objects. No transport or model mutations in the view.
- `AnalysisAnnouncementTracker.mutating func update(_ presentation: AnalysisPresentation) -> AnalysisPresentation?`: return a presentation only for meaningful phase/guidance changes after seeding; initial update returns nil; bytes alone return nil. Seed a changed meeting or a different nonnil job identity without announcing historic permission. A nil→assigned jobID for the same live meeting is ordinary handoff, not reentry: announce the new stage once without repeating unchanged safe guidance.
- `AppTheme.successColor: Color`, `AppTheme.successBackgroundColor: Color`. Light foreground RGB `(0.137, 0.424, 0.286)`, background `(0.918, 0.957, 0.929)`; dark foreground `(0.722, 0.882, 0.776)`, background `(0.125, 0.227, 0.169)`. These match the approved preview; measure composed text contrast in verification, adjust only if needed and record it.

- [ ] **Step 1: Write failing announcement and catalog tests.** `firstRenderDoesNotAnnounce`, `handoffAnnouncesOnce`, `bytesAndRepeatedPollsDoNotAnnounce`, `reentrySeedsWithoutAnnouncement`, `retryThenReregisterAnnouncesNewSafety`, `differentJobSeedsWithoutOldPermission`, `jobAssignedDuringLiveFlowAnnouncesQueueOnly` (same meeting, nil→jobID, safeUpload→safeServer: one queue-stage announcement, no repeated permission sentence).

```swift
@Test func handoffAnnouncesOnce() {
  let id = UUID()
  var tracker = AnalysisAnnouncementTracker()
  let preparing = AnalysisPresentationResolver.resolve(.init(meetingID: id))
  #expect(tracker.update(preparing) == nil)
  var manifest = upload(sent: 0); manifest.meetingID = id
  let safe = AnalysisPresentationResolver.resolve(.init(meetingID: id, upload: manifest))
  #expect(tracker.update(safe)?.guidance == .safeUpload)
  #expect(tracker.update(safe) == nil)
}
```

Here the test's private upload helper has Task 1's same manifest contract; keep shared test helpers in a single test-support file only if actually reused. Catalog tests load built en/it bundles with `Bundle.main.path(forResource:ofType:)` and `Bundle(path:)`, using `#require` to fail rather than skip missing bundles. Assert preparation and safe-upload title/detail equal the spec strings exactly in both languages. Assert every key used by the new view resolves to translated text rather than its key. Do not mutate shared app-language UserDefaults in parallel tests.

- [ ] **Step 2: Run UNIT with both `-only-testing:SnipNoteTests/AnalysisAnnouncementTests` and `-only-testing:SnipNoteTests/AnalysisLocalizationTests` filters.** Expected RED: missing tracker/copy.
- [ ] **Step 3: Implement the tracker and localized rendering.** Add catalog keys under `analysis.*`: `phase.preparing/uploading/server`, `title.preparing/uploading/confirming/queued/transcribing/analyzing/processing/paused/failed`, `guidance.keep_open.title/detail`, `guidance.safe.title`, `guidance.upload.detail`, `guidance.queue.detail`, `guidance.server.detail`, `guidance.attention.title/detail`, `action.retry`, and `progress.accessibility`.

Use the spec's EN/IT copy verbatim. Supplemental exact copy: processing title “Processing your meeting” / “Elaborazione della riunione”; failure “Analysis needs attention” / “L’analisi richiede attenzione”; attention title “Open SnipNote to continue” / “Apri SnipNote per continuare”; attention detail “Check your connection and try again.” / “Controlla la connessione e riprova.” Progress accessibility format “Audio upload: %d%%” / “Caricamento audio: %d%%”. Phase labels “Preparing / Uploading / On the server” and “Preparazione / Caricamento / Sul server”. Format percentage and byte counts with the selected app locale, not an English string interpolation. Recovery details/actions specific to terminal failure remain owned by the existing error UI in Task 3; do not claim audio retention generically.

Use system typography: stage title `.title2` semibold; phase `.caption` medium; guidance title `.subheadline` semibold and detail `.footnote`; byte count `.caption` with monospaced digits. Use `@ScaledMetric` for a base 56-point upload percentage. Horizontal insets 24 points, title/progress separation 24–32, guidance padding 16, guidance radius theme.cornerRadius, line height 4. Maximum content width 480 points on iPad; use minimum visual-space reservation, not fixed total heights. Check Dynamic Type wrapping before tightening spacing.

Use one indeterminate line treatment only; no simultaneously breathing hero. For Reduce Motion show a static activity mark and localized stage with no repeating animation. Stage/guidance opacity changes and upload fill use `.easeOut(duration: 0.25)` scoped to their actual values; never animate the whole view on byte updates. Retain numeric measurement without spring overshoot. Use `.monospacedDigit()`, SF Symbols only, and text rather than color as the safety cue.

Expose identifiers `analysis.stage`, `analysis.guidance.title`, `analysis.guidance.detail`, `analysis.upload.progress`, `analysis.retry`. Progress uses accessible value, decorative graphics are hidden, action hits are at least 44 points. Call tracker in onChange, seed on first appearance, and post only meaningful returned messages (stage text for phase changes; add safe-to-leave text only on a false→true canLeave transition) through the native accessibility announcement API compatible with this project's target. View disappearance/reentry seeds without replay; language changes refresh text but do not announce safety again. No focus-stealing layout notification.

- [ ] **Step 4: Run UNIT filtered to both task suites, then build the app.** Expected GREEN and `BUILD SUCCEEDED`. Command: `xcodebuild build -project SnipNote.xcodeproj -scheme SnipNote -destination 'platform=iOS Simulator,name=iPhone 16,OS=18.5' CODE_SIGNING_ALLOWED=NO`.
- [ ] **Step 5: Commit only Task 2 files.** `git commit -m "Add quiet analysis status surface"`. End-of-task contract: UNIT (all unit tests).

